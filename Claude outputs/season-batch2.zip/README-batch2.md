# Season work – Batch 2: connect the apps, fix predictions and league defaults

This batch connects RRCApp and PublicApp to the season service from Batch 1 and removes the hard-coded season dates from predictions and the league pages. **Behaviour changes in this batch.** Test it against your local database before deploying.

All 10 files are **replacements**. Each one is your current file with the changes applied, and every change is marked `SEASON WORK (batch 2)`. The `#region old` blocks are kept untouched. Line endings and BOMs match your originals. `batch2-changes.diff` shows every changed line if you want to review before copying.

## Files

| File (`C:\Users\u0000770PC\source\repos\…`) | What changes |
|---|---|
| `RRCServices\Calculator\IRacePredictionService.cs` | Uses `ISeasonService` instead of `ISeasonSettingsService`. The season comes from the **race date** (effective season). The hard-coded 2025-11-30 → 2026-11-30 is gone. The season end now uses `<` the day after, so races on the last day are counted. |
| `RRCApp\Program.cs` | Registers `SeasonContext` and `ISeasonService` (scoped). |
| `RRCApp\Components\Pages\RunnerCalculator.razor` | `@inject ISeasonService SeasonService` |
| `RRCApp\Components\Pages\RunnerCalculator.razor.cs` | Loads the seasons once. `Calculate()` picks the season for the **selected race**. Messages now name the season. |
| `RRCApp\Components\Pages\LeagueSummary.razor` | Defaults to the **current season**, not the calendar year. Passes the end of the last day. |
| `PublicApp\Program.cs` | Registers `SeasonContext` and `ISeasonService` (scoped). |
| `PublicApp\Components\Pages\MyDetails.razor` | `@inject ISeasonService SeasonService` |
| `PublicApp\Components\Pages\MyDetails.razor.cs` | Loads the seasons once. The new `ApplySeasonForSelectedRace()` sets `_seasonStart` and `_hasSeasonRaces` for the **selected race**. The hard-coded 2025-12-01 is gone. |
| `PublicApp\Components\Pages\League.razor` | Injects `ISeasonService` and shows "Season 2026: 01 Jan 2026 – 31 Oct 2026". |
| `PublicApp\Components\Pages\League.razor.cs` | Uses the current season instead of 2026-01-01 → 2026-11-30. Reset goes to the current season instead of 2025. Passes the end of the last day. |

## What you should see (testing locally, today = 15 Nov 2026)

| Page | Expected |
|---|---|
| Public **League** | Shows *Season 2026: 01 Jan 2026 – 31 Oct 2026*. Click Load: no race after 31 Oct is scored. |
| Admin **League Summary** | Date boxes show 01/01/2026 and 31/10/2026. |
| Admin **Race Calculator** (`/calcrunnerrace`) | Select the November special race. The prediction uses 2026 races, and the message ends "…from season 2026". |
| Admin predicted times for a race event | For the November race, runners and inputs come from 2026 only. December 2025 is no longer used. |
| Public **My Details** | For the November race, it predicts from 2026 races. For a January 2027 race, if one is listed, it says "please run at least one race this season (from 01 Jan 2027)". |

## Not in this batch (still as before)

- **`Year == 2026` no-target rule** in the league services. This is Batch 3, and must be done before the first 2027 league race.
- **rrcapi and MobApp** still use their own dates. This is Batch 4.
- **The admin Season Settings page and the JSON file** still exist but are no longer used by any prediction or league page. They're removed in Batch 5.

## Deploying to Azure (later)

1. Run `RRCConfig\Sql\001_create_config_season.sql` against the **Azure** database **first**. These pages now read `config.Season`, and if the table is missing they'll show an error.
2. Then publish RRCApp and PublicApp.
