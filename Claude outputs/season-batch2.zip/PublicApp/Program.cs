﻿using Microsoft.EntityFrameworkCore;
using PublicApp.Components;
using RRCConfig.Data;
using RRCDataModel.Data;
using RRCServices;
using RRCServices.Calculator;
using RRCServices.Calculator.RRCServices;
using RRCServices.Clock;
using RRCServices.League;
using RRCServices.Runner;
using RRCServices.Season;

namespace PublicApp;

public class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        //      builder.Services.AddDbContextFactory<RRCContext>(options =>
        //options.UseSqlServer(builder.Configuration.GetConnectionString("RRC")));


        var cs = builder.Configuration.GetConnectionString("RRCAzure");
        if (string.IsNullOrWhiteSpace(cs))
            throw new InvalidOperationException("Connection string 'RRCAzure' not found.");


        ////
        builder.Services.AddDbContextFactory<RRCContext>(options =>
    options.UseSqlServer(cs, sql =>
        sql.EnableRetryOnFailure(
            maxRetryCount: 5,
            maxRetryDelay: TimeSpan.FromSeconds(10),
            errorNumbersToAdd: null)));


        ////

        //builder.Services.AddDbContextFactory<RRCContext>(options =>
        //    options.UseSqlServer(cs));

       // builder.Services.AddDbContextFactory<RRCContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("RRCAzure")));


        builder.Services.AddScoped<IRaceEventService, RaceEventService>();
        builder.Services.AddScoped<IRunnerService, RunnerService>();
        builder.Services.AddScoped<IClock, SystemClock>();
        builder.Services.AddScoped<CalculatorService>();
        builder.Services.AddScoped<IRaceResultService, RaceResultService>();
        builder.Services.AddScoped<ITrophyCalculator, TrophyCalculator>();
        builder.Services.AddSingleton<ITimeFormatter, TimeFormatter>();

        // ✅ Register the settings store (file path wherever you want)
        var seasonSettingsPath = Path.Combine(
            builder.Environment.ContentRootPath,
            "App_Data",
            "seasonSettings.json");

        // ✅ Store + service registrations (required)
        builder.Services.AddSingleton<ISeasonSettingsStore>(_ =>
            new JsonSeasonSettingsStore(seasonSettingsPath));

        builder.Services.AddSingleton<ISeasonSettingsService, SeasonSettingsService>();

        // SEASON WORK (batch 2): seasons live in config.Season in the same
        // database, via their own small SeasonContext (RRCConfig project).
        // MyDetails and League use it. The JSON settings store above is no
        // longer used by any page and is removed in a later batch.
        builder.Services.AddDbContextFactory<SeasonContext>(options =>
            options.UseSqlServer(cs, sql =>
                sql.EnableRetryOnFailure(
                    maxRetryCount: 5,
                    maxRetryDelay: TimeSpan.FromSeconds(10),
                    errorNumbersToAdd: null)));
        builder.Services.AddScoped<ISeasonService, SeasonService>();

        builder.Services.AddScoped<ILeagueTableService, LeagueTableService>();
       // builder.Services.AddScoped<ILeagueDataService, LeagueDataService>();

     


        // Add services to the container.
        builder.Services.AddRazorComponents()
            .AddInteractiveServerComponents();

        var app = builder.Build();

        // Configure the HTTP request pipeline.
        if (!app.Environment.IsDevelopment())
        {
            app.UseExceptionHandler("/Error");
            // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
            app.UseHsts();
        }

        app.UseHttpsRedirection();

        app.UseStaticFiles();
        app.UseAntiforgery();

        app.MapRazorComponents<App>()
            .AddInteractiveServerRenderMode();

        app.Run();
    }
}
