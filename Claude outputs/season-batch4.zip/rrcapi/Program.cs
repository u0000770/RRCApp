using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using System.Threading.RateLimiting;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;

using RRCConfig.Data;
using RRCDataModel.Data;

using RRCServices;
using RRCServices.Clock;
using RRCServices.League;
using RRCServices.League.DTO;
using RRCServices.Runner;
using RRCServices.Season;

var builder = WebApplication.CreateBuilder(args);

// --------------------
// Connection string
// --------------------
var cs = builder.Configuration.GetConnectionString("RRCAzure")
         ?? throw new InvalidOperationException("Missing ConnectionStrings:RRCAzure");

// --------------------
// Swagger
// --------------------
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// --------------------
// CORS
// --------------------
const string CorsPolicyName = "PublicAppCors";
builder.Services.AddCors(options =>
{
    options.AddPolicy(CorsPolicyName, policy =>
    {
        policy.WithOrigins(
                "https://publicapp.example",
                "https://www.publicapp.example",
                "http://localhost:5173",
                "https://localhost:7194",
                "https://localhost:7142"
          )
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

// --------------------
// Rate limiting
// --------------------
builder.Services.AddRateLimiter(options =>
{
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;

    options.AddPolicy("lookup", ctx =>
        RateLimitPartition.GetFixedWindowLimiter(
            ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown",
            _ => new FixedWindowRateLimiterOptions
            {
                PermitLimit = 10,
                Window = TimeSpan.FromMinutes(1),
                QueueLimit = 0
            }));

    options.AddPolicy("public", ctx =>
        RateLimitPartition.GetFixedWindowLimiter(
            ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown",
            _ => new FixedWindowRateLimiterOptions
            {
                PermitLimit = 120,
                Window = TimeSpan.FromMinutes(1),
                QueueLimit = 0
            }));
});

// --------------------
// EF Core (SQL Server + retry)
// --------------------
builder.Services.AddDbContextFactory<RRCContext>(options =>
    options.UseSqlServer(cs, sql =>
        sql.EnableRetryOnFailure(
            maxRetryCount: 3,
            maxRetryDelay: TimeSpan.FromSeconds(10),
            errorNumbersToAdd: null)));

builder.Services.AddDbContext<RRCContext>(options =>
    options.UseSqlServer(cs, sql =>
        sql.EnableRetryOnFailure(
            maxRetryCount: 3,
            maxRetryDelay: TimeSpan.FromSeconds(10),
            errorNumbersToAdd: null)));

// --------------------
// Services
// --------------------
builder.Services.AddScoped<IRunnerService, RunnerService>();
builder.Services.AddScoped<IRaceEventService, RaceEventService>();
builder.Services.AddScoped<ILeagueTableService, LeagueTableService>();

// FIX (batch 2+3): LeagueTableService needs ITrophyCalculator, which was never
// registered here, so /api/v1/league/trophy could not be resolved (HTTP 500).
builder.Services.AddScoped<ITrophyCalculator, TrophyCalculator>();

builder.Services.AddSingleton<IClock, SystemClock>();

// SEASON WORK (batch 2+3): LeagueTableService now uses ISeasonService for the
// no-target rule. Seasons live in config.Season (RRCConfig project).
builder.Services.AddDbContextFactory<SeasonContext>(options =>
    options.UseSqlServer(cs, sql =>
        sql.EnableRetryOnFailure(
            maxRetryCount: 3,
            maxRetryDelay: TimeSpan.FromSeconds(10),
            errorNumbersToAdd: null)));
builder.Services.AddScoped<ISeasonService, SeasonService>();

var app = builder.Build();

app.UseHttpsRedirection();
app.UseCors(CorsPolicyName);
app.UseRateLimiter();

app.UseSwagger();
app.UseSwaggerUI();

// --------------------
// Routes (v1)
// --------------------
var v1 = app.MapGroup("/api/v1");

// POST /api/v1/runners/lookup
v1.MapPost("/runners/lookup",
    async (RunnerLookupRequestDto req, IRunnerService runners, CancellationToken ct) =>
    {
        var hasUkan = !string.IsNullOrWhiteSpace(req.ukAn);
        var hasNameDob =
            !string.IsNullOrWhiteSpace(req.firstName) &&
            !string.IsNullOrWhiteSpace(req.secondName) &&
            req.dob.HasValue;

        if (!hasUkan && !hasNameDob)
            return Results.BadRequest(new ApiErrorDto(
                "Provide UKAN or (firstName + secondName + dob).",
                "VALIDATION"));

        DateTime? dob = req.dob?.ToDateTime(TimeOnly.MinValue);

        var runnerId = await runners.FindRunnerIdAsync(
            req.ukAn,
            req.firstName,
            req.secondName,
            dob,
            ct);

        return Results.Ok(new RunnerLookupResponseDto(runnerId));
    })
    .RequireRateLimiting("lookup")
    .WithOpenApi();

// GET /api/v1/runners/{runnerId}
v1.MapGet("/runners/{runnerId:int}",
    async (int runnerId, bool includeInactiveTimes, IRunnerService runners, CancellationToken ct) =>
    {
        var dto = await runners.GetRunnerDetailsAsync(runnerId, includeInactiveTimes, ct);
        return dto is null
            ? Results.NotFound(new ApiErrorDto("Runner not found", "NOT_FOUND"))
            : Results.Ok(dto);
    })
    .RequireRateLimiting("public")
    .WithOpenApi();

// GET /api/v1/raceevents
v1.MapGet("/raceevents",
    async (bool? activeOnly,
           string? distanceCode,
           DateOnly from,
           DateOnly to,
           IRaceEventService races) =>
    {
        if (to < from)
            return Results.BadRequest(new ApiErrorDto("`to` must be on or after `from`", "VALIDATION"));

        var list = await races.GetRaceEventListAsync(
            activeOnly ?? true,
            distanceCode,
            from.ToDateTime(TimeOnly.MinValue),
            to.ToDateTime(TimeOnly.MaxValue));

        return Results.Ok(list);
    })
    .RequireRateLimiting("public")
    .WithOpenApi();

// GET /api/v1/league/trophy
v1.MapGet("/league/trophy",
    async (DateOnly start,
           DateOnly end,
           ILeagueTableService league,
           CancellationToken ct) =>
    {
        if (end < start)
            return Results.BadRequest(new ApiErrorDto("`end` must be on or after `start`", "VALIDATION"));

        // FIX (batch 2+3): 23:59:59 rather than TimeOnly.MaxValue. The column is SQL
        // 'datetime', which rounds 23:59:59.9999999 up to midnight of the NEXT day,
        // so races on the day after `end` could be counted.
        var page = await league.GetLeagueTablesAsync(
            start.ToDateTime(TimeOnly.MinValue),
            end.ToDateTime(new TimeOnly(23, 59, 59)),
            ct);

        return Results.Ok(page);
    })
    .RequireRateLimiting("public")
    .WithOpenApi();

// --------------------
// Seasons (SEASON WORK, batch 4)
// --------------------
// Lets MobApp (and any future client) read the seasons from config.Season
// instead of hard-coding dates. A season is StartDate..EndDate inclusive.

// GET /api/v1/seasons  — all seasons, newest first
v1.MapGet("/seasons",
    async (ISeasonService seasons, CancellationToken ct) =>
    {
        var list = await seasons.ListAsync(ct);
        return Results.Ok(list.Select(ToSeasonDto).ToList());
    })
    .RequireRateLimiting("public")
    .WithOpenApi();

// GET /api/v1/seasons/effective?date=2026-11-20
// The season whose races are used to predict a race on `date`: the season
// containing it or, between seasons (the special November race), the one that
// has just ended. `date` defaults to today. 404 if before the first season.
v1.MapGet("/seasons/effective",
    async (DateOnly? date, ISeasonService seasons, IClock clock, CancellationToken ct) =>
    {
        var d = date ?? clock.Today;
        var season = await seasons.GetEffectiveAsync(d, ct);

        return season is null
            ? Results.NotFound(new ApiErrorDto($"No season covers {d:yyyy-MM-dd}.", "NOT_FOUND"))
            : Results.Ok(ToSeasonDto(season));
    })
    .RequireRateLimiting("public")
    .WithOpenApi();

static SeasonDto ToSeasonDto(SeasonInfo s)
    => new(s.SeasonId, s.Name, s.StartDate, s.EndDate, s.AllowNoTarget);

app.Run();


// ==================================================
// Type declarations MUST come after app.Run()
// ==================================================

public record ApiErrorDto(string message, string? code = null);

public record RunnerLookupRequestDto(
    string? ukAn,
    string? firstName,
    string? secondName,
    DateOnly? dob);

public record RunnerLookupResponseDto(int? runnerId);

// SEASON WORK (batch 4): JSON shape matches rrc.contracts.SeasonDto
// (seasonId, name, startDate, endDate, allowNoTarget).
public record SeasonDto(
    int seasonId,
    string name,
    DateOnly startDate,
    DateOnly endDate,
    bool allowNoTarget);

public sealed class SystemClock : IClock
{
    public DateTime Now => DateTime.Now;
    public DateTime UtcNow => DateTime.UtcNow;
}
