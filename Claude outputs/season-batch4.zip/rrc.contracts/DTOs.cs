﻿namespace rrc.contracts
{
    // PublicApp.DataApi.DTOs
    // DTOs matching: PublicApp Data API Specification (v1)
    //
    // Notes:
    // - These types are designed to be shared by both the API project and the Blazor WASM client.
    // - Uses DateOnly where the spec calls for date-only (query params and DOB).
    // - Uses DateTimeOffset for event dates/timestamps returned by the API (safe for timezone-aware payloads).
    // - Property names match the JSON shown in the spec; System.Text.Json will use these names by default.

    using System;
    using System.Collections.Generic;
    using System.Text.Json.Serialization;


        // ----------------------------
        // 3.3 Error response (non-2xx)
        // ----------------------------
        public sealed class ApiErrorDto
        {
            [JsonPropertyName("message")]
            public string Message { get; init; } = "";

            [JsonPropertyName("code")]
            public string? Code { get; init; }
        }

        // --------------------------------
        // 4.1 Runner Lookup (Home Page)
        // POST /api/v1/runners/lookup
        // --------------------------------
        public sealed class RunnerLookupRequestDto
        {
            [JsonPropertyName("ukan")]
            public string? Ukan { get; init; }

            [JsonPropertyName("firstName")]
            public string? FirstName { get; init; }

            [JsonPropertyName("secondName")]
            public string? SecondName { get; init; }

            /// <summary>
            /// Date of birth as date-only (YYYY-MM-DD).
            /// </summary>
            [JsonPropertyName("dob")]
            public DateOnly? Dob { get; init; }
        }

        public sealed class RunnerLookupResponseDto
        {
            [JsonPropertyName("runnerId")]
            public int? RunnerId { get; init; }
        }

        // -----------------------------------------
        // 4.2 Runner Details (MyDetails Page)
        // GET /api/v1/runners/{runnerId}
        // -----------------------------------------
        public sealed class RunnerDetailsDto
        {
            /// <summary>Internal runner id.</summary>
            [JsonPropertyName("runnerId")]
            public int RunnerId { get; init; }

            /// <summary>Optional UKAN identifier.</summary>
            [JsonPropertyName("ukan")]
            public string? Ukan { get; init; }

            [JsonPropertyName("firstName")]
            public string? FirstName { get; init; }

            [JsonPropertyName("secondName")]
            public string? SecondName { get; init; }

            /// <summary>Date of birth as date-only.</summary>
            [JsonPropertyName("dob")]
            public DateOnly? Dob { get; init; }

            [JsonPropertyName("isMale")]
            public bool IsMale { get; init; }

            /// <summary>
            /// Race history / event times used by the UI for trophy tables and predictions.
            /// </summary>
            [JsonPropertyName("eventTimes")]
            public List<EventRaceTimesDto> EventTimes { get; init; } = new();
        }

        public sealed class EventRaceTimesDto
        {
            [JsonPropertyName("raceTitle")]
            public string? RaceTitle { get; init; }

            /// <summary>
            /// Timestamp of the race. Use DateTimeOffset to preserve timezone in JSON.
            /// </summary>
            [JsonPropertyName("raceDate")]
            public DateTimeOffset? RaceDate { get; init; }

            /// <summary>
            /// Actual recorded time in seconds (null if not recorded).
            /// </summary>
            [JsonPropertyName("actualSeconds")]
            public int? ActualSeconds { get; init; }

            /// <summary>
            /// Distance in meters (null if unknown).
            /// </summary>
            [JsonPropertyName("distanceMeters")]
            public double? DistanceMeters { get; init; }

            /// <summary>
            /// Distance code string used for age grading, e.g. "5K", "10K".
            /// </summary>
            [JsonPropertyName("raceDistance")]
            public string? RaceDistance { get; init; }

            // Optional (handy for the UI; include if your existing contract already has these)
            [JsonPropertyName("raceId")]
            public int? RaceId { get; init; }

            [JsonPropertyName("eventId")]
            public int? EventId { get; init; }
        }

        // --------------------------------------------
        // 4.3 Race Events List (Races + MyDetails)
        // GET /api/v1/raceevents
        // --------------------------------------------
        public sealed class RaceEventListItemDto
        {
            [JsonPropertyName("active")]
            public bool Active { get; init; }

            [JsonPropertyName("raceEventId")]
            public int RaceEventId { get; init; }

            [JsonPropertyName("eventTitle")]
            public string? EventTitle { get; init; }

            /// <summary>
            /// Date/time of the race event (timezone-aware recommended).
            /// </summary>
            [JsonPropertyName("date")]
            public DateTimeOffset Date { get; init; }

            [JsonPropertyName("distanceCode")]
            public string? DistanceCode { get; init; }

            [JsonPropertyName("distanceMeters")]
            public double DistanceMeters { get; init; }

            [JsonPropertyName("location")]
            public string? Location { get; init; }
        }

        // --------------------------------------------
        // 4.4 Trophy League Tables (League Page)
        // GET /api/v1/league/trophy
        // --------------------------------------------
        public sealed class TrophyLeaguePageDto
        {
            /// <summary>
            /// Season window used to generate the league (echoed back for clarity).
            /// </summary>
            [JsonPropertyName("start")]
            public DateOnly Start { get; init; }

            [JsonPropertyName("end")]
            public DateOnly End { get; init; }

            /// <summary>
            /// One or more sections/tables displayed by the UI.
            /// Keep flexible to match your existing contract.
            /// </summary>
            [JsonPropertyName("tables")]
            public List<TrophyLeagueTableDto> Tables { get; init; } = new();
        }

        public sealed class TrophyLeagueTableDto
        {
            /// <summary>
            /// Table/section title (e.g. "Overall", "Female", "Male", "V40", etc).
            /// </summary>
            [JsonPropertyName("title")]
            public string Title { get; init; } = "";

            /// <summary>
            /// Optional description/subtitle shown in UI.
            /// </summary>
            [JsonPropertyName("description")]
            public string? Description { get; init; }

            [JsonPropertyName("rows")]
            public List<TrophyLeagueRowDto> Rows { get; init; } = new();
        }

        public sealed class TrophyLeagueRowDto
        {
            [JsonPropertyName("position")]
            public int Position { get; init; }

            [JsonPropertyName("runnerId")]
            public int RunnerId { get; init; }

            [JsonPropertyName("runnerName")]
            public string RunnerName { get; init; } = "";

            [JsonPropertyName("ukan")]
            public string? Ukan { get; init; }

            /// <summary>
            /// Total points for the season window.
            /// </summary>
            [JsonPropertyName("points")]
            public int Points { get; init; }

            /// <summary>
            /// Optional: count of scoring races, if your UI shows it.
            /// </summary>
            [JsonPropertyName("racesCount")]
            public int? RacesCount { get; init; }

            /// <summary>
            /// Optional: best improvements/time-diff summary in seconds.
            /// (Your current UI formats seconds to mm:ss.)
            /// </summary>
            [JsonPropertyName("timeDiffSeconds")]
            public int? TimeDiffSeconds { get; init; }
        }

        // --------------------------------------------
        // 4.5 Seasons (SEASON WORK, batch 4)
        // GET /api/v1/seasons
        // GET /api/v1/seasons/effective?date=yyyy-MM-dd
        // --------------------------------------------
        // A season runs StartDate..EndDate inclusive (normally 01 Jan .. 31 Oct).
        // "effective" = the season containing the date or, between seasons
        // (the special November race), the season that has just ended. That is
        // the season whose races are used to predict a race on that date.
        public sealed class SeasonDto
        {
            [JsonPropertyName("seasonId")]
            public int SeasonId { get; init; }

            [JsonPropertyName("name")]
            public string Name { get; init; } = "";

            /// <summary>First day of the season (inclusive).</summary>
            [JsonPropertyName("startDate")]
            public DateOnly StartDate { get; init; }

            /// <summary>Last day of the season (inclusive).</summary>
            [JsonPropertyName("endDate")]
            public DateOnly EndDate { get; init; }

            /// <summary>No-target rule: a race with no target scores a flat 6 points.</summary>
            [JsonPropertyName("allowNoTarget")]
            public bool AllowNoTarget { get; init; }
        }
    }


