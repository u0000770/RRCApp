﻿


namespace rrc.client.Services;

using System.Globalization;
using System.Net;
using System.Net.Http.Json;
using rrc.contracts;

public sealed class RaceEventApiClient
{
    private readonly HttpClient _http;

    public RaceEventApiClient(HttpClient http)
    {
        _http = http;
    }

    // ============================================================
    // RACE EVENTS
    // ============================================================
    public async Task<List<RaceEventListItemDto>> GetRaceEventsAsync(
        bool activeOnly,
        string? distanceCode,
        DateOnly from,
        DateOnly to,
        CancellationToken ct = default)
    {
        var fromStr = from.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
        var toStr = to.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);

        var url =
            "/api/v1/raceevents" +
            $"?activeOnly={activeOnly.ToString().ToLowerInvariant()}" +
            $"&from={Uri.EscapeDataString(fromStr)}" +
            $"&to={Uri.EscapeDataString(toStr)}";

        if (!string.IsNullOrWhiteSpace(distanceCode))
            url += $"&distanceCode={Uri.EscapeDataString(distanceCode)}";

        using var resp = await _http.GetAsync(url, ct);
        resp.EnsureSuccessStatusCode();

        return await resp.Content.ReadFromJsonAsync<List<RaceEventListItemDto>>(cancellationToken: ct)
               ?? new List<RaceEventListItemDto>();
    }

    // ============================================================
    // RUNNER LOOKUP (Home.razor needs this)
    // POST /api/v1/runners/lookup
    // ============================================================
    public async Task<int?> LookupRunnerIdAsync(
        string? ukan,
        string? firstName,
        string? secondName,
        DateOnly? dob,
        CancellationToken ct = default)
    {
        var req = new RunnerLookupRequestDto
        {
            Ukan = ukan,
            FirstName = firstName,
            SecondName = secondName,
            Dob = dob
        };

        using var resp = await _http.PostAsJsonAsync("/api/v1/runners/lookup", req, ct);
        resp.EnsureSuccessStatusCode();

        var result = await resp.Content.ReadFromJsonAsync<RunnerLookupResponseDto>(cancellationToken: ct);
        return result?.RunnerId;
    }

    // ============================================================
    // RUNNER DETAILS (MyDetails.razor likely needs this)
    // GET /api/v1/runners/{runnerId}
    // ============================================================
    public async Task<RunnerDetailsDto?> GetRunnerAsync(
        int runnerId,
        bool includeInactiveTimes = false,
        CancellationToken ct = default)
    {
        var url =
            $"/api/v1/runners/{runnerId}" +
            $"?includeInactiveTimes={includeInactiveTimes.ToString().ToLowerInvariant()}";

        using var resp = await _http.GetAsync(url, ct);

        if (resp.StatusCode == HttpStatusCode.NotFound)
            return null;

        resp.EnsureSuccessStatusCode();

        return await resp.Content.ReadFromJsonAsync<RunnerDetailsDto>(cancellationToken: ct);
    }

    // ============================================================
    // SEASONS (SEASON WORK, batch 4)
    // GET /api/v1/seasons/effective?date=yyyy-MM-dd
    // ============================================================
    // The season whose races are used to predict a race on `date`: the season
    // containing it or, between seasons (the special November race), the one
    // that has just ended. Null if no season covers the date (404).
    public async Task<SeasonDto?> GetEffectiveSeasonAsync(
        DateOnly date,
        CancellationToken ct = default)
    {
        var dateStr = date.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
        var url = $"/api/v1/seasons/effective?date={Uri.EscapeDataString(dateStr)}";

        using var resp = await _http.GetAsync(url, ct);

        if (resp.StatusCode == HttpStatusCode.NotFound)
            return null;

        resp.EnsureSuccessStatusCode();

        return await resp.Content.ReadFromJsonAsync<SeasonDto>(cancellationToken: ct);
    }
}

