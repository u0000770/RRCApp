using Xunit;
using RRCServices;
using RRCServices.League;
using RRCServices.League.DTO;
using RRCServices.Season;

namespace RRCServices.Tests.Seasons;

// =============================================================================
// NoTargetRuleTests — season-driven no-target rule (SEASON WORK, batch 2+3)
// =============================================================================
// Replaces the hard-coded "Year == 2026". A race with an actual time but NO
// target scores a flat 6 points if it falls inside a season whose
// AllowNoTarget flag is on. Seasons as seeded by 001_create_config_season.sql:
//   2025 off, 2026 on, 2027 on. Between seasons (Nov–Dec): never.
//
// LeagueTableService.ApplyNoTargetRule and ScoreRunner are internal; the test
// project sees them through InternalsVisibleTo("RRCServices.Tests").
// =============================================================================
public class NoTargetRuleTests
{
    private static SeasonInfo S(int id, int year, bool allowNoTarget)
        => new(id, year.ToString(),
               new SeasonWindow(new DateOnly(year, 1, 1), new DateOnly(year, 10, 31)),
               allowNoTarget);

    private static readonly IReadOnlyList<SeasonInfo> Seasons = new[]
    {
        S(1, 2025, allowNoTarget: false),
        S(2, 2026, allowNoTarget: true),
        S(3, 2027, allowNoTarget: true),
    };

    private static LeagueRaceDto Race(DateTime date, int target, int actual)
        => new()
        {
            RunnerId = 1,
            RunnerName = "Test Runner",
            DistanceCode = "5km",
            RaceDate = date,
            TargetSeconds = target,
            ActualSeconds = actual,
            HasTarget = target > 0
        };

    // ---- SeasonRules.AllowsNoTarget -----------------------------------------

    [Theory]
    [InlineData(2025, 6, 1, false)]   // 2025 season: rule off
    [InlineData(2026, 6, 1, true)]    // 2026 season: rule on
    [InlineData(2026, 10, 31, true)]  // last day of 2026
    [InlineData(2026, 11, 20, false)] // special November race: between seasons
    [InlineData(2027, 1, 1, true)]    // 1 Jan 2027 race: rule on
    [InlineData(2028, 3, 1, false)]   // no 2028 season row yet
    public void AllowsNoTarget(int y, int m, int d, bool expected)
        => Assert.Equal(expected, SeasonRules.AllowsNoTarget(Seasons, new DateOnly(y, m, d)));

    // ---- LeagueTableService.ApplyNoTargetRule -------------------------------

    [Fact]
    public void ApplyNoTargetRule_KeepsEveryRaceWithATarget_InAnySeasonOrGap()
    {
        var races = new List<LeagueRaceDto>
        {
            Race(new DateTime(2025, 6, 1), 1500, 1490),
            Race(new DateTime(2026, 6, 1), 1500, 1490),
            Race(new DateTime(2026, 11, 20), 1500, 1490),
        };

        Assert.Equal(3, LeagueTableService.ApplyNoTargetRule(races, Seasons).Count);
    }

    [Fact]
    public void ApplyNoTargetRule_KeepsNoTargetRaces_OnlyWhereSeasonAllows()
    {
        var races = new List<LeagueRaceDto>
        {
            Race(new DateTime(2025, 6, 1), 0, 1490),          // dropped: 2025 off
            Race(new DateTime(2026, 6, 1), 0, 1490),          // kept
            Race(new DateTime(2026, 11, 20), 0, 1490),        // dropped: between seasons
            Race(new DateTime(2027, 1, 1, 10, 0, 0), 0, 1490) // kept: 1 Jan 2027 race
        };

        var kept = LeagueTableService.ApplyNoTargetRule(races, Seasons);

        Assert.Equal(
            new[] { new DateTime(2026, 6, 1), new DateTime(2027, 1, 1, 10, 0, 0) },
            kept.Select(r => r.RaceDate).ToArray());
    }

    // ---- ScoreRunner with a no-target race ----------------------------------

    [Fact]
    public void ScoreRunner_NoTargetRace_ScoresFlatSix_AndNoTimeDiff()
    {
        // The 1 Jan 2027 race: no targets exist, everyone who finishes gets 6.
        var races = new List<LeagueRaceDto> { Race(new DateTime(2027, 1, 1), 0, 1490) };

        var line = LeagueTableService.ScoreRunner(1, "Test Runner", null, races, topN: 8, new TrophyCalculator());

        Assert.Equal(6, line.Points);
        Assert.Equal(0, line.TimeDiffSeconds);
    }
}
