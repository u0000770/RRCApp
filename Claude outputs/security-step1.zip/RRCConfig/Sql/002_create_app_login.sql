/* =============================================================================
   002_create_app_login.sql
   -----------------------------------------------------------------------------
   Creates a dedicated, least-privilege database user for the three apps
   (RRCApp, PublicApp, rrcapi), so they stop connecting as the SQL server admin.

   * Run it against the APP DATABASE (free-sql-db-0703531), NOT master.
     It creates a "contained" user: a login that exists only in this database.
   * The user can read and write data in every schema (dbo and config) but
     cannot create, alter or drop tables, or manage users. The apps never
     need to: there are no EF migrations.
   * Before running, replace <<CHOOSE-A-STRONG-PASSWORD>> with a new, long,
     random password (e.g. 24+ characters from a password manager). Keep it
     in your password manager, NOT in any file in the solution.
   * Safe to re-run: if the user already exists, the password is changed
     to the one below.
   ============================================================================= */

IF DATABASE_PRINCIPAL_ID(N'rrc_app') IS NULL
    CREATE USER rrc_app WITH PASSWORD = N'<<CHOOSE-A-STRONG-PASSWORD>>';
ELSE
    ALTER USER rrc_app WITH PASSWORD = N'<<CHOOSE-A-STRONG-PASSWORD>>';

ALTER ROLE db_datareader ADD MEMBER rrc_app;
ALTER ROLE db_datawriter ADD MEMBER rrc_app;

-- Check: should list rrc_app with db_datareader and db_datawriter
SELECT u.name AS [user], r.name AS [role]
FROM   sys.database_role_members m
JOIN   sys.database_principals u ON u.principal_id = m.member_principal_id
JOIN   sys.database_principals r ON r.principal_id = m.role_principal_id
WHERE  u.name = N'rrc_app';
