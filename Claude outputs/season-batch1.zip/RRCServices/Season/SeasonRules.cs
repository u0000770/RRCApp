namespace RRCServices.Season;

// =============================================================================
// SeasonRules — pure, database-free season logic
// =============================================================================
// Kept separate from SeasonService so every rule can be unit-tested without a
// database.
//
// AGREED RULES (15 Nov 2026):
//   1. A season is an inclusive date range (normally 01 Jan .. 31 Oct).
//   2. Dates between seasons (01 Nov .. 31 Dec) belong to NO season.
//      League pages and scoring use the CONTAINING season only, so the
//      special November race is never scored.
//   3. Predictions use the EFFECTIVE season: the containing season, or, in
//      the gap, the most recent season that has already ended. So the
//      special November race is predicted from that year's races.
//   4. Predictions reset on 01 Jan: the new season has started, so only
//      its races count.
//   5. Seasons may not overlap, and names must be unique.
// =============================================================================
public static class SeasonRules
{
    public const int MaxNameLength = 20;

    /// <summary>The season whose dates include <paramref name="date"/>, or null if it falls between seasons.</summary>
    public static SeasonInfo? FindContaining(IEnumerable<SeasonInfo> seasons, DateOnly date)
        => seasons.FirstOrDefault(s => s.Window.Contains(date));

    /// <summary>
    /// The containing season, or, if <paramref name="date"/> falls between
    /// seasons, the most recent season that ended before it. Null only if
    /// the date is before the first season.
    /// </summary>
    public static SeasonInfo? FindEffective(IEnumerable<SeasonInfo> seasons, DateOnly date)
    {
        var list = seasons as IReadOnlyCollection<SeasonInfo> ?? seasons.ToList();

        return FindContaining(list, date)
            ?? list.Where(s => s.Window.End < date)
                   .OrderByDescending(s => s.Window.End)
                   .FirstOrDefault();
    }

    /// <summary>Returns a list of problems; an empty list means the edit is valid.</summary>
    public static IReadOnlyList<string> Validate(SeasonEdit edit, IEnumerable<SeasonInfo> existing)
    {
        var errors = new List<string>();
        var name = edit.Name?.Trim() ?? string.Empty;

        if (name.Length == 0)
            errors.Add("Season name is required.");
        else if (name.Length > MaxNameLength)
            errors.Add($"Season name must be {MaxNameLength} characters or fewer.");

        if (edit.EndDate < edit.StartDate)
        {
            errors.Add("Season end date must be on or after the start date.");
            return errors; // can't build a window to check overlaps
        }

        var window = new SeasonWindow(edit.StartDate, edit.EndDate);

        foreach (var other in existing.Where(s => s.SeasonId != edit.SeasonId))
        {
            if (string.Equals(other.Name, name, StringComparison.OrdinalIgnoreCase))
                errors.Add($"A season called '{other.Name}' already exists.");

            if (other.Window.Overlaps(window))
                errors.Add($"Dates overlap season '{other.Name}' ({other.Window}).");
        }

        return errors;
    }
}
