using Xunit;
using RRCServices.Season;

namespace RRCServices.Tests.Seasons;

// =============================================================================
// SeasonRulesTests — agreed season rules (15 Nov 2026)
// =============================================================================
//   Season = 01 Jan .. 31 Oct.  01 Nov .. 31 Dec is between seasons.
//   League  -> containing season only (special Nov race never scored).
//   Predict -> effective season (gap uses the season just ended).
//   Reset   -> 01 Jan starts the new season.
// =============================================================================
public class SeasonRulesTests
{
    private static SeasonInfo S(int id, int year, bool allowNoTarget = true)
        => new(id, year.ToString(),
               new SeasonWindow(new DateOnly(year, 1, 1), new DateOnly(year, 10, 31)),
               allowNoTarget);

    private static readonly IReadOnlyList<SeasonInfo> Seasons = new[]
    {
        S(1, 2025, allowNoTarget: false),
        S(2, 2026),
        S(3, 2027),
    };

    private static DateOnly D(int y, int m, int d) => new(y, m, d);

    // ---- FindContaining ----------------------------------------------------

    [Theory]
    [InlineData(2026, 1, 1, "2026")]
    [InlineData(2026, 6, 15, "2026")]
    [InlineData(2026, 10, 31, "2026")]
    [InlineData(2027, 1, 1, "2027")]
    public void FindContaining_InSeason(int y, int m, int d, string expected)
        => Assert.Equal(expected, SeasonRules.FindContaining(Seasons, D(y, m, d))?.Name);

    [Theory]
    [InlineData(2026, 11, 1)]   // 1 Nov is between seasons
    [InlineData(2026, 11, 20)]  // special November race
    [InlineData(2026, 12, 31)]
    [InlineData(2024, 6, 1)]    // before any season
    public void FindContaining_BetweenSeasons_IsNull(int y, int m, int d)
        => Assert.Null(SeasonRules.FindContaining(Seasons, D(y, m, d)));

    // ---- FindEffective -----------------------------------------------------

    [Theory]
    [InlineData(2026, 6, 15, "2026")]   // in season
    [InlineData(2026, 11, 1, "2026")]   // gap -> season just ended
    [InlineData(2026, 11, 20, "2026")]  // special race predicted from 2026 races
    [InlineData(2026, 12, 31, "2026")]
    [InlineData(2027, 1, 1, "2027")]    // predictions reset on 1 Jan
    [InlineData(2028, 3, 1, "2027")]    // no 2028 row yet -> latest ended season
    public void FindEffective(int y, int m, int d, string expected)
        => Assert.Equal(expected, SeasonRules.FindEffective(Seasons, D(y, m, d))?.Name);

    [Fact]
    public void FindEffective_BeforeFirstSeason_IsNull()
        => Assert.Null(SeasonRules.FindEffective(Seasons, D(2024, 12, 31)));

    [Fact]
    public void FindEffective_UnorderedInput_StillPicksLatestEnded()
    {
        var shuffled = new[] { Seasons[2], Seasons[0], Seasons[1] };
        Assert.Equal("2026", SeasonRules.FindEffective(shuffled, D(2026, 11, 20))?.Name);
    }

    // ---- Validate ----------------------------------------------------------

    private static SeasonEdit Edit(int id, string name, DateOnly start, DateOnly end)
        => new() { SeasonId = id, Name = name, StartDate = start, EndDate = end };

    [Fact]
    public void Validate_NewNonOverlappingSeason_IsValid()
        => Assert.Empty(SeasonRules.Validate(
            Edit(0, "2028", D(2028, 1, 1), D(2028, 10, 31)), Seasons));

    [Fact]
    public void Validate_EditingItself_IsNotAnOverlap()
        => Assert.Empty(SeasonRules.Validate(
            Edit(2, "2026", D(2026, 1, 1), D(2026, 10, 15)), Seasons));

    [Fact]
    public void Validate_Overlap_IsRejected()
    {
        var errors = SeasonRules.Validate(
            Edit(0, "2026b", D(2026, 10, 1), D(2026, 12, 31)), Seasons);
        Assert.Contains(errors, e => e.Contains("overlap"));
    }

    [Fact]
    public void Validate_DuplicateName_IsRejected_CaseInsensitive()
    {
        var errors = SeasonRules.Validate(
            Edit(0, " 2026 ", D(2030, 1, 1), D(2030, 10, 31)), Seasons);
        Assert.Contains(errors, e => e.Contains("already exists"));
    }

    [Fact]
    public void Validate_EndBeforeStart_IsRejected()
    {
        var errors = SeasonRules.Validate(
            Edit(0, "2029", D(2029, 10, 31), D(2029, 1, 1)), Seasons);
        Assert.Contains(errors, e => e.Contains("on or after"));
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    [InlineData("123456789012345678901")] // 21 chars
    public void Validate_BadName_IsRejected(string name)
        => Assert.NotEmpty(SeasonRules.Validate(
            Edit(0, name, D(2029, 1, 1), D(2029, 10, 31)), Seasons));
}
