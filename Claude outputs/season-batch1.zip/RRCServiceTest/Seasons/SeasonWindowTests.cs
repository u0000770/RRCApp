using Xunit;
using RRCServices.Clock;
using RRCServices.Season;

namespace RRCServices.Tests.Seasons;

// =============================================================================
// SeasonWindowTests — inclusive date range + IClock.Today
// =============================================================================
public class SeasonWindowTests
{
    private static readonly SeasonWindow Season2026 =
        new(new DateOnly(2026, 1, 1), new DateOnly(2026, 10, 31));

    [Fact]
    public void FromInclusive_IsMidnightOfFirstDay()
        => Assert.Equal(new DateTime(2026, 1, 1, 0, 0, 0), Season2026.FromInclusive);

    [Fact]
    public void ToExclusive_IsMidnightOfDayAfterLastDay()
        => Assert.Equal(new DateTime(2026, 11, 1, 0, 0, 0), Season2026.ToExclusive);

    [Theory]
    [InlineData(2026, 1, 1, 0, 0, true)]     // first moment
    [InlineData(2026, 10, 31, 0, 0, true)]   // last day, midnight
    [InlineData(2026, 10, 31, 19, 30, true)] // last day, evening race (old code dropped this)
    [InlineData(2026, 11, 1, 0, 0, false)]   // 1 Nov is between seasons
    [InlineData(2025, 12, 31, 23, 59, false)]
    public void Contains_DateTime(int y, int m, int d, int hh, int mm, bool expected)
        => Assert.Equal(expected, Season2026.Contains(new DateTime(y, m, d, hh, mm, 0)));

    [Theory]
    [InlineData(2026, 1, 1, true)]
    [InlineData(2026, 10, 31, true)]
    [InlineData(2026, 11, 1, false)]
    [InlineData(2026, 11, 20, false)] // special November race
    public void Contains_DateOnly(int y, int m, int d, bool expected)
        => Assert.Equal(expected, Season2026.Contains(new DateOnly(y, m, d)));

    [Fact]
    public void Constructor_EndBeforeStart_Throws()
        => Assert.Throws<ArgumentException>(() =>
            new SeasonWindow(new DateOnly(2026, 10, 31), new DateOnly(2026, 1, 1)));

    [Fact]
    public void Constructor_SingleDay_IsAllowed()
    {
        var w = new SeasonWindow(new DateOnly(2026, 5, 1), new DateOnly(2026, 5, 1));
        Assert.True(w.Contains(new DateOnly(2026, 5, 1)));
    }

    [Theory]
    [InlineData(2027, 1, 1, 2027, 10, 31, false)]  // next season
    [InlineData(2026, 10, 31, 2027, 10, 31, true)] // shares last day
    [InlineData(2025, 1, 1, 2026, 1, 1, true)]     // shares first day
    [InlineData(2026, 3, 1, 2026, 4, 1, true)]     // inside
    public void Overlaps(int y1, int m1, int d1, int y2, int m2, int d2, bool expected)
    {
        var other = new SeasonWindow(new DateOnly(y1, m1, d1), new DateOnly(y2, m2, d2));
        Assert.Equal(expected, Season2026.Overlaps(other));
    }

    [Fact]
    public void Clock_Today_IsDatePartOfNow()
    {
        IClock clock = new FixedClock(new DateTime(2026, 11, 15, 23, 30, 0));
        Assert.Equal(new DateOnly(2026, 11, 15), clock.Today);
    }
}
