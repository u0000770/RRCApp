using Microsoft.EntityFrameworkCore;
using RRCConfig.Models;

namespace RRCConfig.Data;

// =============================================================================
// SeasonContext — EF Core context for the 'config' schema only
// =============================================================================
// Shares the RRCAzure connection string with RRCContext but is completely
// independent of it.
//
// NO EF MIGRATIONS: the table is created by Sql/001_create_config_season.sql,
// which you run by hand. Never run Add-Migration / Update-Database against
// this context.
// =============================================================================
public sealed class SeasonContext : DbContext
{
    public const string Schema = "config";

    public SeasonContext(DbContextOptions<SeasonContext> options)
        : base(options)
    {
    }

    public DbSet<SeasonRecord> Seasons => Set<SeasonRecord>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema(Schema);

        modelBuilder.Entity<SeasonRecord>(e =>
        {
            e.ToTable("Season", Schema);
            e.HasKey(x => x.SeasonId);

            e.Property(x => x.Name)
             .HasMaxLength(20)
             .IsRequired();

            e.Property(x => x.StartDate).HasColumnType("date");
            e.Property(x => x.EndDate).HasColumnType("date");

            e.Property(x => x.CreatedUtc).HasColumnType("datetime2(0)");
            e.Property(x => x.UpdatedUtc).HasColumnType("datetime2(0)");

            e.HasIndex(x => x.Name).IsUnique();
        });
    }
}
