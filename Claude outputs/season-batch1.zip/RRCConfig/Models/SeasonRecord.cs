namespace RRCConfig.Models;

// =============================================================================
// SeasonRecord — one row of config.Season
// =============================================================================
// A season is a block of dates in which league races count.
//   e.g. "2026" = 01 Jan 2026 .. 31 Oct 2026 (both inclusive)
//
// Dates between seasons (1 Nov .. 31 Dec) belong to no season. The special
// November race falls in that gap: it is predicted using the season that has
// just ended, but it is never scored in the league.
//
// This is a persistence class only. Application code should use
// RRCServices.Season.SeasonInfo, returned by ISeasonService.
// =============================================================================
public sealed class SeasonRecord
{
    public int SeasonId { get; set; }

    /// <summary>Display name, e.g. "2026". Unique.</summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>First day of the season (inclusive).</summary>
    public DateOnly StartDate { get; set; }

    /// <summary>Last day of the season (inclusive).</summary>
    public DateOnly EndDate { get; set; }

    /// <summary>
    /// When true, a league race with no target time still scores a flat
    /// 6 points. Replaces the old hard-coded "Year == 2026" rule.
    /// </summary>
    public bool AllowNoTarget { get; set; }

    public DateTime CreatedUtc { get; set; }
    public DateTime UpdatedUtc { get; set; }
}
